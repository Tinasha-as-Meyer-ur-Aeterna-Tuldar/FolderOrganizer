//
//  FolderOrganizerTests.swift
//  FolderOrganizerTests
//
//  Created by 望月慎一 on 2025/12/01.
//

import Testing
@testable import FolderOrganizer

struct FolderOrganizerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
