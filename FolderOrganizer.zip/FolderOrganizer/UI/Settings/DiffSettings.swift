import Foundation

enum DiffSettings {
    /// Diff 表示の ON / OFF を保存するキー
    static let showDiffKey = "showDiffPreview"
}
