//
//  ExportVersion.swift
//  FolderOrganizer
//

import Foundation

enum ExportVersion: String, Codable {
    case v1
}
