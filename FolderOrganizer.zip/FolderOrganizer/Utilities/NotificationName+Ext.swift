//
//  Utilities/NotificationName+Ext.swift
//  FolderOrganizer
//

import Foundation

extension Notification.Name {
    static let openDetailFromList = Notification.Name("openDetailFromList")
}
